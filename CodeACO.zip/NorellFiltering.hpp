//
//  NorellFiltering.hpp
//  HoughPith
//
//  Created by Remi DECELLE on 01/10/2019.
//  Copyright © 2019 Remi DECELLE. All rights reserved.
//

#ifndef NorellFiltering_hpp
#define NorellFiltering_hpp

#include <stdio.h>
#include <iostream>
#include "opencv2/core.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"

#include "ICA.hpp"

using namespace cv;
using namespace std;

Mat fft2(const Mat& I, Mat& complexI);
Mat norell_filter(Mat I, double lambda, double sigma_line);

#endif /* NorellFiltering_hpp */
