//
//  bresenham.hpp
//  
//
//  Created by Remi DECELLE on 10/07/2020.
//

#ifndef bresenham_hpp
#define bresenham_hpp

#include <stdio.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;

Mat longuetaud(const Mat orient, const Mat grad);

#endif /* bresenham_hpp */
