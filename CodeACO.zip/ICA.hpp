//
//  ICA.hpp
//  
//
//  Created by Remi DECELLE on 08/01/2020.
//

#ifndef ICA_hpp
#define ICA_hpp

#include <stdio.h>
#include <opencv2/core.hpp>

void remean(cv::Mat input,cv::Mat & output);
void remean(cv::Mat& input,cv::Mat& output,cv::Mat & mean);
void whiten(cv::Mat input,cv::Mat &output);
void whiten(cv::Mat input,cv::Mat &output,cv::Mat &E,cv::Mat &D);
void runICA(cv::Mat input, cv::Mat &output,cv::Mat &W,int snum);

#endif /* ICA_hpp */
