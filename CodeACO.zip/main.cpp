//
//  main.cpp
//  AntColonyPith
//
//  Created by Remi DECELLE on 11/12/2019.
//  Copyright © 2019 Remi DECELLE. All rights reserved.
//
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <random>

#include "preprocess.hpp"
//#include "NorellFiltering.hpp"
#include "orientation/ridgeorient.hpp"
#include "normal/bresenham.hpp"
//#include "ICA.hpp"

using namespace cv;
using namespace std;

int radius = 300;//12;
int max_radius = 350;//50;
Mat img, gimg;
int thresh = 100;

float medianMat(Mat Input, int nVals);
//Mat longuetaud(const Mat orient, const Mat grad);
//Mat get_orientation_by_gabor(const Mat &gimg, double wavelength, int nx_subimage, int ny_subimage);
Rect getROI(const Mat &img, Point corner, int size);

Point ant_colony(   const Mat &img,
                    const Mat &orient,
                    double scale,
                    int num_ants,
                    int num_blocs,
                    int bloc_size,
                    int quantizer,
                    double kappa,
                    double evaporation_rate,
                    double alpha, double beta,
                    int max_num_it, double epsilon,
                    bool animation);



int main(int argc, char** argv)
{
    // 1. Initialize timer
    double tt_tic, tt_toc;
    tt_tic = cv::getTickCount();
    
    // 2. Read file and input image
    string filename = "../samples/douglas.jpeg"; //harvest.jpeg logyard.jpg sawmill.png spruce.jpg;
    if( argc > 1)
        filename = argv[1];
    img = imread(filename, 1);
    
    // 3.1 Read parameters
    double scale = 0.4;       // Resize input image
    int div_x = 4, div_y = 4;  // Number of sub-images in x-axis and y-axis
    double gradientsigma = 2.0, blocksigma = 4.0; // Gaussian standard deviation for local orientation
    
    int num_ants  = 4; // The parameter K
    int num_blocs = 3; // The parameter n
    int bloc_size = 8; // The parameter omega
    int quantizer = 4; // The parameter m
    
    double alpha = 2.0;   // ACO alpha
    double beta  = 1.0;   // ACO beta
    double gamma = 0.07;  // ACO gamma
    
    double lambda = 0.875, linesigma = 6.0; // Two parameters in sawings marks removal
    
    double kappa=0.8, epsilon=2.0;
    
    int max_num_iter = 50;
    bool animation = false;
    // Need to include epsilon
    //../samples/harvest.jpeg -s 0.4 -x 4 -y 4 -u 2 -v 4 -n 4 -c 3 -o 8 -q 4 -a 2 -b 1 -g 0.07 -l 0.6 -w 0.875 -i 50 -k 0.8 -e 2.0

    if ( argc > 2)
    {
        for (int i = 2; i < argc; i+=2)
        {
            //printf("%s\n",argv[i]);
            if (string(argv[i]).at(0) == '-')
            {
                printf("%s ==> %s\n",argv[i],argv[i+1]);
                if (string(argv[i]) == string ("--scale") || string(argv[i]) == string("-s"))
                    scale = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--dx") || string(argv[i]) == string("-x"))
                    div_x = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--dy") || string(argv[i]) == string("-y"))
                    div_y = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--gsigma") || string(argv[i]) == string("-u"))
                    gradientsigma = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--bsigma") || string(argv[i]) == string("-v"))
                    blocksigma = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--lsigma") || string(argv[i]) == string("-w"))
                    linesigma = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--ant") || string(argv[i]) == string("-n"))
                    num_ants = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--block") || string(argv[i]) == string("-c"))
                    num_blocs = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--omega") || string(argv[i]) == string("-o"))
                    bloc_size = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--quantizer") || string(argv[i]) == string("-q"))
                    quantizer = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--alpha") || string(argv[i]) == string("-a"))
                    alpha = atof(argv[i+1]);
               else if (string(argv[i]) == string ("--beta") || string(argv[i]) == string("-b"))
                    beta = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--gamma") || string(argv[i]) == string("-g"))
                    gamma = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--lambda") || string(argv[i]) == string("-l"))
                    lambda = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--iter") || string(argv[i]) == string("-i"))
                    max_num_iter = atoi(argv[i+1]);
                else if (string(argv[i]) == string ("--kappa") || string(argv[i]) == string("-k"))
                    kappa = atof(argv[i+1]);
                else if (string(argv[i]) == string ("--epsilon") || string(argv[i]) == string("-e"))
                    epsilon = atof(argv[i+1]);
                
            }
        }
    }
    
    // 4. Apply preprocessing
    tt_tic = cv::getTickCount();
    // Convert into grayscale. Beware that cv::imread create BGR image and not RGB !
    cvtColor(img, gimg, COLOR_BGR2GRAY);
    // Resizing
    resize(gimg, gimg, Size(scale * gimg.cols, scale * gimg.rows));
    // Padding image
    int padx = ceil(gimg.cols / (float)div_x) * div_x; // 4x3 subimages
    int pady = ceil(gimg.rows / (float)div_y) * div_y; // 4x3 subimages
    copyMakeBorder(gimg, gimg, 0, pady - gimg.rows, 0, padx - gimg.cols, BORDER_REPLICATE);
    tt_toc = cv::getTickCount();
    cerr << "Step 1: Pre processing in " << (tt_toc - tt_tic) / getTickFrequency() <<" seconds"<< endl;
    
    // 5. Retrieve orientation with Jain filter and Sawing Marks removal
    tt_tic = cv::getTickCount();
    gimg.convertTo(gimg, CV_32F);
    Mat full_orientation = quadrant_orientation(gimg, div_x, div_y, gradientsigma, blocksigma, lambda, linesigma); // 1.0 is useless
    tt_toc = cv::getTickCount();
    cerr << "Step 2: Orientation computation in " << (tt_toc - tt_tic) / getTickFrequency() <<" seconds"<< endl;
    
    // 6. Process Ant Colony
    tt_tic = cv::getTickCount();
    Point first_estimate = ant_colony(img, full_orientation, scale,
                                      num_ants, num_blocs, bloc_size, quantizer, kappa,
                                      gamma, alpha, beta, max_num_iter, epsilon, animation);
    tt_toc = cv::getTickCount();
    cerr << "Step 3: Frist Ant Colony estimation " << (tt_toc - tt_tic) / getTickFrequency() <<" seconds"<< endl;

    // II.1 Second iteration
    int ww = 512;
    if(min(img.cols,img.rows)<ww);//FIXME: ww
        ww = min(img.cols,img.rows)/4;
    int px = first_estimate.x;
    int py = first_estimate.y;
    int ex = static_cast<int>((px-ww/2)*scale); // scale = 0.4 //FIXME: ww
    int ey = static_cast<int>((py-ww/2)*scale); //FIXME: ww
    int delta = static_cast<int>(ww*scale); //FIXME: ww
    // 2.1 Retrieve small area around first estimation and resize
    //tt_tic = cv::getTickCount();
    cvtColor(img, gimg, COLOR_BGR2GRAY);
    resize(gimg, gimg, Size(scale * gimg.cols, scale * gimg.rows));
    copyMakeBorder(gimg, gimg, 0, pady - gimg.rows, 0, padx - gimg.cols, BORDER_REPLICATE);
    ///gimg = gimg(Rect(ex, ey, delta, delta)); //FIXME: ROI
    Rect roi = getROI(gimg, Point(ex,ey), delta);
    gimg = gimg(roi);
    //tt_toc = cv::getTickCount();
    //cout << "Pre processing: " << (tt_toc - tt_tic) / getTickFrequency() << endl;
    
    // 2.2 Apply sawing marks removal
    //tt_tic = cv::getTickCount();
    gimg.convertTo(gimg, CV_32F);
    //tt_toc = cv::getTickCount();
    //cout << (tt_toc - tt_tic) / getTickFrequency() << endl;
    gimg = sawing_marks_removal(gimg, lambda, linesigma);
    
    // 2.3 Get orientation
    //tt_tic = cv::getTickCount();
    full_orientation = estimate_orientation(gimg, gradientsigma, blocksigma, 1.0);
    
    /*
     * Change in parameter for the second pass
     */
    tt_tic = cv::getTickCount();
    quantizer = quantizer/2;
    epsilon   = epsilon/4.0;
    Point second_estimate = ant_colony(gimg, full_orientation, 1.0,
                                       num_ants, num_blocs, bloc_size, quantizer, kappa,
                                       gamma, alpha, beta, max_num_iter, epsilon, animation);
    ///std::cerr<<"ant_colony"<<std::endl;
    // Retrieve correct position in the full image coordinate
    second_estimate.x = second_estimate.x + px - (ww*scale/2); //FIXME: ww
    second_estimate.y = second_estimate.y + py - (ww*scale/2); //FIXME: ww
    
    tt_toc = cv::getTickCount();
    cerr << "Step 4: Second Ant Colony estimation " << (tt_toc - tt_tic) / getTickFrequency() <<" seconds"<< endl;
    
    cerr<<"First pith estimation (in pink): "<<first_estimate.x<<", "<<first_estimate.y<<endl;
    cerr<<"Second pith estimation (in blue): "<<second_estimate.x<<", "<<second_estimate.y<<endl;
    // Draw both first and second estimated piths
    Mat display;
    img.copyTo(display);
    drawMarker(display, first_estimate, Scalar(255,0,255), MARKER_CROSS, 64, 10);
    drawMarker(display, second_estimate, Scalar(255,0,0), MARKER_CROSS, 64, 10);
    if(animation) {
        imshow("Resultat", display);
        waitKey();
    }
    imwrite("Result.png", display);
    return 0;
}

Point ant_colony(const Mat &img,
                 const Mat &orient,
                 double scale,
                 int num_ants,
                 int num_blocs,
                 int bloc_size,
                 int quantizer,
                 double kappa,
                 double evaporation_rate,
                 double alpha, double beta,
                 int max_num_it, double epsilon,
                 bool animation)
{
    int delta = floor(num_blocs * bloc_size * 0.5);
    //int block_count = num_blocs * num_blocs;
    
    Mat displayer;
    
    // 1. Initialize
    vector<Point> ants;
    int height = scale * img.rows;
    int width  = scale * img.cols;
    int hq  = floor(height / quantizer);
    int wq  = floor(width / quantizer);
    double delta_y = height / num_ants;
    double delta_x = width / num_ants;
    for (int i = 0; i<num_ants; i++) {
        for (int j = 0; j<num_ants; j++) {
            //int k   = i * num_ants + j;
            int ay  = floor(i*delta_y+floor(delta_y/2));
            int ax  = floor(j*delta_x+floor(delta_x/2));
            ants.push_back(Point(ax,ay));
        }
    }
    
    // 2. Iterate
    std::default_random_engine generator;
    Mat global_model = Mat::zeros(hq, wq, CV_32F);
    vector<double> distances;
    Point p(-1,-1);
    int it = 0;
    //for (int it = 0; it<max_num_it; it++)
    for(;;)
    {
        if (animation)
        {
            img.copyTo(displayer);
            resize(displayer, displayer, Size(scale * displayer.cols, scale * displayer.rows));
            displayer.convertTo(displayer, CV_32F);
            cv::normalize(displayer, displayer, 0, 1, cv::NORM_MINMAX);
            for (Point ant: ants) {
                drawMarker(displayer, ant, Scalar(0,127,255), MARKER_CROSS, 32, 10);
            }
            imshow("Ant Colony", displayer);
            Mat tmp;
            normalize(global_model, tmp, 0, 1, NORM_MINMAX);
            imshow("Accumulation", tmp);
            waitKey(70);
        }
        Mat tau = Mat::zeros(hq, wq, CV_32F);
        //for (Point ant: ants)
        
        for (int i = 0; i<ants.size(); i++)
        {
            Point ant = ants.at(i);
            //Mat anto = Mat::zeros(hq, wq, CV_32F);
            //Mat antg = Mat::zeros(hq, wq, CV_8U);
            vector<Point3d> linepos;
            for (int n = 0; n<num_blocs; n++) {
                for (int m = 0; m<num_blocs; m++) {
                    int dy = ant.y - delta + n*bloc_size;
                    int dx = ant.x - delta + m*bloc_size;
                    ///Mat sub_orient = orient(Rect(dx, dy, bloc_size, bloc_size));//FIXME: ROI
                    Rect roi = getROI(orient, Point(dx,dy), bloc_size);
                    Mat sub_orient = orient(roi);
                    //float theta = medianMat(sub_orient, 4096);
                    float theta = static_cast<float>(mean(sub_orient)[0]);
                    int cx = ant.x - delta + m * bloc_size + bloc_size/2;
                    int cy = ant.y - delta + n * bloc_size + bloc_size/2;
                    cx = floor(cx/quantizer);
                    cy = floor(cy/quantizer);
                    //anto.at<float>(cy,cx)   = theta;
                    //antg.at<uint8_t>(cy,cx) = 255;
                    linepos.push_back(Point3d(cx, cy, theta));
                }
            }
            //Mat A = longuetaud(anto, antg);
            Mat A = accumulate_normals(linepos, hq, wq);
            //waitKey();
            A = A > 0;
            A &= 0x1;
            A.convertTo(A, tau.type());
            
            tau = tau + A;
            
            Mat mask = Mat::zeros(hq, wq, CV_8U) + Scalar(255);
            Mat dist = Mat::zeros(hq, wq, CV_32F) + Scalar(255);
            int aqx = floor(ant.x / quantizer);
            int aqy = floor(ant.y / quantizer);
            mask.at<uint8_t>(aqy, aqx) = 0;
            distanceTransform(mask, dist, DIST_L2, 3);
            normalize(dist, dist, 0.0, 1.0, NORM_MINMAX);
            pow(dist+Scalar(1), -1.0, dist);
            //imshow("Dist", dist);
            //waitKey();
            
            Mat Q, proba;
            double s = cv::sum( global_model )[0];
            if (s == 0)
                proba = Mat::ones(hq, wq, CV_32F) / (hq * wq);
            else
                proba = global_model / s;
            
            //Q = (proba.^alpha) .* (dist.^beta);
            pow(proba, alpha, proba);
            pow(dist, beta, dist);
            multiply(proba, dist, Q);
            proba = Q / (cv::sum( Q )[0]);
            
            // Choose a col
            Mat pcol;
            cv::reduce(proba, pcol, 0, cv::REDUCE_SUM);
            std::vector<float> _col(pcol.rows);
            pcol.row(0).copyTo(_col);
            cv::normalize(_col, _col, 0, 1, cv::NORM_MINMAX);
            std::discrete_distribution<int> cdistribution (_col.begin(), _col.end());
            int cnumber = cdistribution(generator);
            
            // Choose a row
            Mat prow;
            std::vector<float> _row(pcol.rows);
            proba.col(cnumber).copyTo(_row);
            cv::normalize(_row, _row, 0, 1, cv::NORM_MINMAX);
            std::discrete_distribution<int> rdistribution (_row.begin(), _row.end());
            int rnumber = rdistribution(generator);
            //double tt_toc = cv::getTickCount();
            //std::cout << "Time to retrieve number: " << (tt_toc - tt_tic) / cv::getTickFrequency() << std::endl;
            //std::cout << "Col x Row: " << cnumber << " " << rnumber << std::endl;
            int py = rnumber;
            int px = cnumber;
            
            //cout << py << "-" << px << "::" << number << endl;
            // Update ants position
            py = quantizer * py;
            px = quantizer * px;
            py = max(min(py, height - delta - 1), delta+1);
            px = max(min(px, width  - delta - 1), delta+1);
            
            //ant.y = py;
            //ant.x = px;
            ants.at(i).x = px;
            ants.at(i).y = py;
        }
        
        global_model = (1-evaporation_rate) * global_model + tau;
        
        double minVal, maxVal;
        Point minLoc, maxLoc;
        minMaxLoc(global_model, &minVal, &maxVal, &minLoc, &maxLoc);
        Mat binary = global_model>=kappa*maxVal;
        //Mat locations;
        //findNonZero(binary, locations);
        Moments m = moments(binary);
        Point q(m.m10/m.m00, m.m01/m.m00);
        
        distances.push_back(sqrt((p.x-q.x)^2 + (p.y-q.y)^2));
        p = q;
        it++;
        if (it > max_num_it) break;
        
        double meandis = DBL_MAX;
        if (it >= 5)
        {
            meandis = 0;
            for (int k=it-5; k<it; k++) {
                meandis += distances.at(k);
            }
            meandis = meandis / 5.0;
        }
        if (meandis < epsilon) break;
    }
    double minVal, maxVal;
    Point minLoc, maxLoc;
    minMaxLoc(global_model, &minVal, &maxVal, &minLoc, &maxLoc);
    Mat binary = global_model>=kappa*maxVal;
    Moments m = moments(binary);
    Point q(m.m10/m.m00, m.m01/m.m00);
    //maxLoc.y = quantizer * maxLoc.y / scale;
    //maxLoc.x = quantizer * maxLoc.x / scale;
    q.y = quantizer * q.y / scale;
    q.x = quantizer * q.x / scale;
    return q;
}

Rect getROI(const Mat &img, Point corner, int size) {
    int p1x = corner.x;
    int p1y = corner.y;
    if(p1x<0) p1x=0;
    if (p1y<0) p1y = 0;
    int p2x = corner.x + size;
    int p2y = corner.y + size;
    if(p2x>=img.cols) p2x = img.cols - 1;
    if(p2y>=img.rows) p2y = img.rows - 1;
    int w = p2x - p1x;
    int h = p2y - p1y;
    if(w<0) w=0;
    if(h<0) h=0;
    return Rect(p1x,p1y,w,h);
}

