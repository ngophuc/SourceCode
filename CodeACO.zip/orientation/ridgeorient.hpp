//
//  ridgeorient.hpp
//  
//
//  Created by Remi DECELLE on 13/01/2020.
//

#ifndef ridgeorient_hpp
#define ridgeorient_hpp

#include <stdio.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include "../preprocess.hpp"

void gradient(cv::Mat image, cv::Mat xGradient, cv::Mat yGradient);
cv::Mat estimate_orientation(const cv::Mat &im, double gradientsigma, double blocksigma, double orientsmoothsigma);
cv::Mat quadrant_orientation(const cv::Mat &gimg, int nx_subimage, int ny_subimage, double gradientsigma, double blocksigma, double lambda, double linesigma);
#endif /* ridgeorient_hpp */
